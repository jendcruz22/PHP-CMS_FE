<?php

$connect = mysqli_connect( "sql311.epizy.com", "epiz_31251901", "cD3SRe0FDG", "epiz_31251901_portfolio" );

mysqli_set_charset( $connect, 'UTF8' );
 
?>